# Online-Disease-Detection-and-Prediction-Analysis

![webapp](https://user-images.githubusercontent.com/57487500/95652533-4ed61500-0b0f-11eb-9205-b6ce0bf497c0.png)
![webapp1](https://user-images.githubusercontent.com/57487500/95652493-061e5c00-0b0f-11eb-9df3-63531792ffa1.png)

### Run the Application

To run this application in your local machine first install all the dependencies.
then run below command 
```bash
manage.py runserver 8000
```

### MediBot

It provides doctors recommendation on the basis of disease predicted through symptoms selected by the user.

![chatbot_console1](https://user-images.githubusercontent.com/57487500/95652776-3ebf3500-0b11-11eb-8816-f25701d33715.png)
